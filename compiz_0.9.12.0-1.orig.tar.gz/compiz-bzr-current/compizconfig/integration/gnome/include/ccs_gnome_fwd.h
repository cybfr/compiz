#ifndef _CCS_GNOME_INTEGRATION_FWD_H
#define _CCS_GNOME_INTEGRATION_FWD_H

#include <ccs-defs.h>

COMPIZCONFIG_BEGIN_DECLS

typedef struct _CCSGNOMEIntegratedSettingInfo CCSGNOMEIntegratedSettingInfo;
typedef struct _CCSGNOMEValueChangeData CCSGNOMEValueChangeData;

COMPIZCONFIG_END_DECLS

#endif
